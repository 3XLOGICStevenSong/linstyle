/*
Navicat MySQL Data Transfer

Source Server         : 192.168.11.100_3306
Source Server Version : 50096
Source Host           : 192.168.11.100:3306
Source Database       : yltappdb

Target Server Type    : MYSQL
Target Server Version : 50096
File Encoding         : 65001

Date: 2017-04-05 15:16:33
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_back_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_back_user`;
CREATE TABLE `sys_back_user` (
  `BACK_USER_ID` int(11) NOT NULL auto_increment COMMENT '管理员用户ID',
  `LOGIN_CODE` varchar(20) NOT NULL COMMENT '账号',
  `USER_NAME` varchar(20) NOT NULL COMMENT '用户名',
  `PASSWORD` varchar(256) NOT NULL COMMENT '密码, SHA512加密',
  `SALT` varchar(64) NOT NULL COMMENT '密码散列用的盐，随即生成',
  `STATUS` tinyint(1) unsigned NOT NULL default '1' COMMENT '0：不可用1：可用',
  `CREATE_TIME` datetime NOT NULL COMMENT '创建时间',
  `UPDATE_TIME` datetime NOT NULL COMMENT '修改时间',
  `LAST_LOGIN_IP` varchar(64) default NULL COMMENT '上次登录IP',
  PRIMARY KEY  (`BACK_USER_ID`),
  UNIQUE KEY `uniqueName` (`LOGIN_CODE`),
  KEY `findOneIndex` (`LOGIN_CODE`,`STATUS`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='系统账户表';

-- ----------------------------
-- Records of sys_back_user
-- ----------------------------
INSERT INTO `sys_back_user` VALUES ('1', 'admin', '管理员', '2e54299e2e3d84481888a89a098dd1d4c3b8cc9048e848f8ab267edf08d6475ac89312380187f467a9a9776e4874e27b9786bb70d7404850e2d1db2917fe1667', 'A1DAF854D0F8AB3FE5E932EA41E02EBB0D23DEE3E219B5A8F47F805B02D7865F', '1', '2017-03-21 14:03:22', '2017-03-21 14:03:22', null);
INSERT INTO `sys_back_user` VALUES ('2', 'user', '普通用户', '546613cfd672242c44407a96b392a7bd2317df015c09b79f3196d5e208b61d818704ddfd4635f2640957c44be0881393d070edc6cdf855c360cbb7d0661b6c31', 'A4DF79054F687C97C8E62D693CBEEA907633BF1A37BBA48D159F37334FCF5867', '1', '2017-03-23 11:35:38', '2017-03-23 11:35:38', null);
INSERT INTO `sys_back_user` VALUES ('3', 'ldyy', '普通用户', 'fba3295210e9d62be1fdcc09eab138b7e18e6f9b392d7ca23673659f4154f5b3882d3d938c574e7e39747801fa24a641e017768ad82d4a07d829d1d36740eead', 'F78BA9308570B3B384D4AACA634E1DCF9B208812DC8C7CD7D1FFD5E0F54C7FAE', '1', '2017-04-05 14:35:15', '2017-04-05 14:35:15', null);
