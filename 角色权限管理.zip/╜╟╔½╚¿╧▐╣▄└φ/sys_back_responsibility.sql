/*
Navicat MySQL Data Transfer

Source Server         : 192.168.11.100_3306
Source Server Version : 50096
Source Host           : 192.168.11.100:3306
Source Database       : yltappdb

Target Server Type    : MYSQL
Target Server Version : 50096
File Encoding         : 65001

Date: 2017-04-05 15:16:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_back_responsibility
-- ----------------------------
DROP TABLE IF EXISTS `sys_back_responsibility`;
CREATE TABLE `sys_back_responsibility` (
  `USER_ID` int(10) unsigned NOT NULL COMMENT '用户ID',
  `ROLE_ID` int(10) unsigned NOT NULL COMMENT '角色ID',
  PRIMARY KEY  (`USER_ID`,`ROLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_back_responsibility
-- ----------------------------
INSERT INTO `sys_back_responsibility` VALUES ('1', '1');
INSERT INTO `sys_back_responsibility` VALUES ('1', '2');
