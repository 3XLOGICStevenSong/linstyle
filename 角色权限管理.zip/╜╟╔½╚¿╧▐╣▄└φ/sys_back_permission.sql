/*
Navicat MySQL Data Transfer

Source Server         : 192.168.11.100_3306
Source Server Version : 50096
Source Host           : 192.168.11.100:3306
Source Database       : yltappdb

Target Server Type    : MYSQL
Target Server Version : 50096
File Encoding         : 65001

Date: 2017-04-05 15:17:02
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_back_permission
-- ----------------------------
DROP TABLE IF EXISTS `sys_back_permission`;
CREATE TABLE `sys_back_permission` (
  `ROLE_ID` int(10) unsigned NOT NULL COMMENT '角色ID',
  `RESOURCE_ID` int(10) unsigned NOT NULL COMMENT '资源ID',
  PRIMARY KEY  (`ROLE_ID`,`RESOURCE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_back_permission
-- ----------------------------
INSERT INTO `sys_back_permission` VALUES ('1', '1');
INSERT INTO `sys_back_permission` VALUES ('1', '2');
INSERT INTO `sys_back_permission` VALUES ('1', '3');
INSERT INTO `sys_back_permission` VALUES ('1', '4');
INSERT INTO `sys_back_permission` VALUES ('1', '9');
INSERT INTO `sys_back_permission` VALUES ('1', '10');
INSERT INTO `sys_back_permission` VALUES ('1', '11');
INSERT INTO `sys_back_permission` VALUES ('1', '12');
INSERT INTO `sys_back_permission` VALUES ('1', '13');
INSERT INTO `sys_back_permission` VALUES ('1', '14');
INSERT INTO `sys_back_permission` VALUES ('2', '5');
INSERT INTO `sys_back_permission` VALUES ('2', '6');
INSERT INTO `sys_back_permission` VALUES ('2', '7');
INSERT INTO `sys_back_permission` VALUES ('2', '8');
