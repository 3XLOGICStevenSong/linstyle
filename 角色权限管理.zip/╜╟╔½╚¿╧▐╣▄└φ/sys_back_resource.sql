/*
Navicat MySQL Data Transfer

Source Server         : 192.168.11.100_3306
Source Server Version : 50096
Source Host           : 192.168.11.100:3306
Source Database       : yltappdb

Target Server Type    : MYSQL
Target Server Version : 50096
File Encoding         : 65001

Date: 2017-04-05 15:16:54
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_back_resource
-- ----------------------------
DROP TABLE IF EXISTS `sys_back_resource`;
CREATE TABLE `sys_back_resource` (
  `RESOURCE_ID` int(10) unsigned NOT NULL COMMENT '资源ID',
  `PARENT_ID` int(10) NOT NULL,
  `RESOURCE_NAME` varchar(200) NOT NULL COMMENT '资源名',
  `RESOURCE_TYPE` varchar(45) NOT NULL,
  `URL` varchar(256) NOT NULL COMMENT 'URL',
  `PERMISSION` varchar(256) NOT NULL COMMENT '权限字符串',
  `ORDER` int(11) NOT NULL,
  `STATUS` tinyint(1) unsigned NOT NULL default '1' COMMENT '可用标志',
  `CREATE_TIME` datetime NOT NULL COMMENT '创建时间',
  `UPDATE_TIME` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY  (`RESOURCE_ID`),
  UNIQUE KEY `uniqueName` (`RESOURCE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_back_resource
-- ----------------------------
INSERT INTO `sys_back_resource` VALUES ('1', '0', '系统管理', 'menu', '#', '', '1', '1', '2017-03-22 16:55:41', '2017-03-22 16:55:41');
INSERT INTO `sys_back_resource` VALUES ('2', '1', '用户管理', 'menu', '/management/user', 'user:*', '1', '1', '2017-03-22 16:55:41', '2017-03-22 16:55:41');
INSERT INTO `sys_back_resource` VALUES ('3', '1', '角色管理', 'menu', '/management/role', 'role:*', '2', '1', '2017-03-22 16:55:41', '2017-03-22 16:55:41');
INSERT INTO `sys_back_resource` VALUES ('4', '1', '资源管理', 'menu', '/management/resource', 'resource:*', '3', '1', '2017-03-22 16:55:41', '2017-03-22 16:55:41');
INSERT INTO `sys_back_resource` VALUES ('5', '0', '日报', 'menu', '/report', 'dr:*', '2', '1', '2017-03-22 16:55:41', '2017-03-22 16:55:41');
INSERT INTO `sys_back_resource` VALUES ('6', '0', '营业', 'menu', '/sales', 'sl:*', '3', '1', '2017-03-22 16:55:41', '2017-03-22 16:55:41');
INSERT INTO `sys_back_resource` VALUES ('7', '0', '客户', 'menu', '/customers', 'ct:*', '4', '1', '2017-03-22 16:55:41', '2017-03-22 16:55:41');
INSERT INTO `sys_back_resource` VALUES ('8', '0', '财务', 'menu', '/fc', 'fc:*', '5', '1', '2017-03-22 16:55:41', '2017-03-22 16:55:41');
INSERT INTO `sys_back_resource` VALUES ('9', '2', '创建用户', 'action', ' ', 'user:create', '0', '1', '2017-03-22 16:55:41', '2017-03-22 16:55:41');
INSERT INTO `sys_back_resource` VALUES ('10', '1', '测试资源菜单', 'menu', '/testresource', 'testresource:*', '4', '1', '2017-03-22 16:55:41', '2017-03-22 16:55:41');
INSERT INTO `sys_back_resource` VALUES ('11', '10', '创建测试资源', 'action', ' ', 'testresource:create', '0', '1', '2017-03-22 16:55:41', '2017-03-22 16:55:41');
INSERT INTO `sys_back_resource` VALUES ('12', '10', '更新测试资源', 'action', ' ', 'testresource:update', '0', '1', '2017-03-22 16:55:41', '2017-03-22 16:55:41');
INSERT INTO `sys_back_resource` VALUES ('13', '10', '删除测试资源', 'action', ' ', 'testresource:delete', '0', '1', '2017-03-22 16:55:41', '2017-03-22 16:55:41');
INSERT INTO `sys_back_resource` VALUES ('14', '10', '查看测试资源', 'action', ' ', 'testresource:view', '0', '1', '2017-03-22 16:55:41', '2017-03-22 16:55:41');
