/*
Navicat MySQL Data Transfer

Source Server         : 192.168.11.100_3306
Source Server Version : 50096
Source Host           : 192.168.11.100:3306
Source Database       : yltappdb

Target Server Type    : MYSQL
Target Server Version : 50096
File Encoding         : 65001

Date: 2017-04-05 15:16:41
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_back_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_back_role`;
CREATE TABLE `sys_back_role` (
  `ROLE_ID` int(10) unsigned NOT NULL auto_increment COMMENT '自角色ID',
  `ROLE_NAME` varchar(200) NOT NULL COMMENT '角色名',
  `STATUS` tinyint(1) unsigned NOT NULL default '1' COMMENT '可用标志',
  `CREATE_TIME` datetime NOT NULL COMMENT '创建时间',
  `UPDATE_TIME` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY  (`ROLE_ID`),
  UNIQUE KEY `uniqueName` (`ROLE_NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_back_role
-- ----------------------------
INSERT INTO `sys_back_role` VALUES ('1', '系统管理员', '1', '2017-03-22 16:41:01', '2017-03-22 16:41:01');
INSERT INTO `sys_back_role` VALUES ('2', '经理', '1', '2017-03-22 16:41:01', '2017-03-22 16:41:01');
