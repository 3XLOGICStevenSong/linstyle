/**
 * Report API features.
 * 
 * Url: https://report.jpush.cn/v3/report/
 */
package cn.jpush.api.report;